__author__ = 'siddharth.porwal@blazeclan.com'

import json
import boto3
import time
from os import getenv
from datetime import datetime, timedelta

# Env variables
# athena_database  : instago
# s3_bucket_name   : instago-prod-h1-athena-query-result
# s3_output_folder : lead-tracking-not-met

ATHENA_DB = getenv("athena_database")
S3_BUCKET = getenv("s3_bucket_name")

RETRY_COUNT = 100

# AWS resources
s3 = boto3.resource("s3")
client = boto3.client('athena')

# Date string
PreYEAR = ((datetime.today() + timedelta(hours=5.5))-timedelta(days=1)).strftime('%Y')
PreMONTH = ((datetime.today() + timedelta(hours=5.5))-timedelta(days=1)).strftime('%b')
PreDAY = ((datetime.today() + timedelta(hours=5.5))-timedelta(days=1)).strftime('%d')

YEAR = (datetime.today() + timedelta(hours=5.5)).strftime('%Y')
MONTH = (datetime.today() + timedelta(hours=5.5)).strftime('%b')
DAY = (datetime.today() + timedelta(hours=5.5)).strftime('%d')

queries = """
SELECT ROW_NUMBER() OVER(order by FCD.agentcode ,
FCD.date) AS "S.No", 
FCD.agentcode as "Agent Code",
FAV.user_name as "Agent Name",
FAV.employee_type as AgentType,
FAV.fls_code as "FLS Code",
FAV.fls_name as "FLS Name",
FCD.date as "Date", 
date_format(from_iso8601_timestamp(FCD.clockin),'%T') as "Clock In",
date_format(from_iso8601_timestamp(FCD.clockout),'%T') as "Clock out",  
FCD.timespan as "Time Span", 
FCD.location as "Location", 
If (FCD.status ='Failure','Unsuccessful','Success') as "Status",
If (FCD.is_System_Closure ='true','Yes','No') as "System Closure",
FCD.channel as "Channel",
FCD.subchannel as "Sub Channel"
from "instago_mis"."fc_attendance_details_partitioned_date" as FCD left outer join "instago_mis"."h1_fls_app_version_data_for_fc_attendance" as FAV on FCD.agentcode=FAV.user_id  
where (FCD.channel='Agency' and FCD.subchannel<>'ABP') 
and date_trunc('month',(cast(FCD.attendance_date as date)))=date_trunc('month',(current_date-interval '1' day))
####################SELECT ROW_NUMBER() OVER(order by FCD.agentcode ,
FCD.date) AS "S.No", 
FCD.agentcode as "Agent Code",
FAV.user_name as "Agent Name",
FAV.employee_type as AgentType,
FAV.fls_code as "FLS Code",
FAV.fls_name as "FLS Name",
FCD.date as "Date", 
date_format(from_iso8601_timestamp(FCD.clockin),'%T') as "Clock In",
date_format(from_iso8601_timestamp(FCD.clockout),'%T') as "Clock out",  
FCD.timespan as "Time Span", 
FCD.location as "Location", 
If (FCD.status ='Failure','Unsuccessful','Success') as "Status",
If (FCD.is_System_Closure ='true','Yes','No') as "System Closure",
FCD.channel as "Channel",
FCD.subchannel as "Sub Channel"
from "instago_mis"."fc_attendance_details_partitioned_date" as FCD left outer join "instago_mis"."h1_fls_app_version_data_for_fc_attendance" as FAV on FCD.agentcode=FAV.user_id  
where (FCD.subchannel='ABP' or FCD.channel='Agency Business Partner') 
and date_trunc('month',(cast(FCD.attendance_date as date)))=date_trunc('month',(current_date-interval '1' day))
####################SELECT 
    AMD."emp_id" as "Emp ID",
    AMD."name" as "Name",
    AMD."emp_band" as "Emp Band",
    AMD."is_fls" as "Is Fls",
    AMD."l1_id" as "L1 ID",
    AMD."l1_name" as "L1 Name",
    AMD."l2_id" as "L2 Name",
    AMD."l2_name" as "L2 Name",
    AMD."l3_id" as "L3 ID",
    AMD."l3_name" as "L3 Name",
    AMD."channel_name" as "Channel Name",
    AMD."person_met" as "Person Met",
    AMD."designation" as "Designation",
    AMD."vertical" as "Vertical",
    AMD."reasons_for_shortfall" as "Reasons for shortfall/deficit",
    AMD."event_id" as "Event ID", 
    AMD."review_date_time" as "Review Date & Time",
    AMD."review_period_from_date" as "Review Period - From date",
    AMD."review_period_to_date" as "Review for the period",
    AMD."performance_of_last_month" as  "Performance of last month",
    AMD."actionable" as "Actionables for next period",
    AMD."actionable_last_meeting" as "Progress on Actionables of Last Meeting", 
    AMD."actionable_current__meeting" as "Detailed Reason/Actionables of current meeting", AMD."timelines" as "Timelines for closure", 
    UC."meeting_mode" as "Meeting Mode",
    AMD."agenda" as "Agenda", AMD."submit_date" as "Submit Date"
FROM annexure_meeting_data_flatten as AMD
Left join instago_prod_h1_user_calendar as UC on UC."event_id"=AMD."event_id"
where (TRY(date_trunc('month',date_parse(AMD."submit_date",'%Y-%m-%d'))) =TRY(date_trunc('month',current_date - interval '1' day))  and TRY(date_trunc('year',date_parse(AMD."submit_date",'%Y-%m-%d'))) = date_trunc('year',current_date - interval '1' day))
and AMD."channel_name"='Bancassurance IDFC'
####################SELECT
    res.channel AS Channel,
    res.user_id AS User_id,
    date_format(date_parse(res.login_time,'%Y-%m-%dT%H:%i:%s.%fZ'),'%d/%m/%y %H:%i') AS Login_date

FROM (
    SELECT
        AL.user_id AS user_id,
        FA.channel AS channel,
        AL.event_time AS login_time

    FROM h1_app_login_logs  AS AL
        LEFT JOIN h1_fls_app_version  AS FA
            ON AL.user_id = FA.user_id
        WHERE AL.tokenstatus = 'SUCCESS' and 
        TRY(date_trunc('month',date_parse(event_time,'%Y-%m-%dT%H:%i:%s.%fZ'))) = date_trunc('month',current_date - interval '1' day) and
        TRY(date_trunc('year',date_parse(event_time,'%Y-%m-%dT%H:%i:%s.%fZ'))) = date_trunc('year',current_date - interval '1' day)

) AS res
####################Select 
 res."Emp Id",
 res."Name",
 res."Emp Band",
 res."Is Fls",
 res."L1 Id",
 res."L1 Name",
 res."L2 Id",
 res."L2 Name",
 res."L3 Id",
 res."L3 Name",
 res."Channel",
 res."Sub Channel",
 res."Partner Id",
 res."Partner",
 res."Partner Name",
 res."State Name",
 res."Branch Name",
 res."Meeting Date",
 res."Meeting Time",
 res."START_TIME",
 res."END_TIME",
case when res.ts <= 0 then ' ' else
         lpad(cast(abs(floor(date_diff('second', sttime,ettime)/3600)) as varchar),2,'0')||':'||
lpad(cast(abs(floor(date_diff('second', sttime,ettime)/60)-floor(date_diff('second', sttime,ettime)/3600)*60) as varchar),2,'0')||':'||
lpad(cast(mod(date_diff('second', sttime,ettime),60) as varchar),2,'0')
         end as
"TimeSpent (HH:MM:SS)",
 res."MEETINGSTATUS",
 res."Person Met",
 res."Designation",
 res."Vertical",
 res."Sub Vertical",
res."Location",
res."No of Home Loan Files Disbursed Last Month",
    res."No of CP Sourced last month",
    res."Unit Penetration Last Month",
    res."No of Home Loan Files Disbursed in current  Month",
    res."No of CP Sourced in current month",
    res."Unit Penetration in current Month",
    res."Unit Penetration Growth/ De-growth/ Actionable",
    res."VP Last Month",
    res."VP Current Month",
    res."Value Penetration Growth/ De-growth/ Actionable",
    res."Tenure Ratio Last Month",
    res."Tenure Ratio Current Month",
    res."Tenure Ratio Growth/ De-growth/ Actionable",
    res."Sum Assured Ratio last Month",
    res."Sum Assured Ratio Current Month",
    res."Sum Assured Growth/ De-growth/ Actionable",
    res."CI Rider attachment Last Month",
    res."CI Rider attachment Current  Month",
    res."CI Growth/ De-growth/ Actionable",
    res."ADB Rider attachment Last Month",
    res."ADB Rider attachment Current Month",
    res."ADB Growth/ De-growth/ Actionable",
    res."Total Rider attachment last Month",
    res."Total Rider attachment Current Month",
    res."Total Rider Growth/ De-growth/ Actionable",
    res."Underwriting cases pending with Sales as on date",
    res."Underwriting Timeline for decision",
    res."Underwriting cases pending with HDFC Life UW Team as on date",
    res."Underwriting Timeline for Closure",
    res."Claim cases pending with Sales as on date",
    res."Claim Timeline for closure",
    res."Claim cases pending with HDFC Life Group Claims Team as on date",
    res."Claim Timeline for decision",
   res."How many Prarambh Training Conducted",
    res."How many people covered",
    res."Availability of marketing collateral in branch",
   res."Remark",
   res."Event ID"
From(SELECT
    FAV."channel" as "Channel",
    FAV."sub_channel" as "Sub Channel",
    AMD."partner_id" as "Partner Id",
    PM."partner" as "Partner",
    UC."meeting_start_time" as "START_TIME",
    UC."meeting_end_time" as "END_TIME",
    date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p') as sttime,
  case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end as ettime,
    date_diff('second', date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end

                  ) as ts,
  case when UC.meeting_status = 'started' then 'ongoing'

  when UC.meeting_status = 'ended' and (date_diff('second', date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end

                  ) >= 900)then 'successful'

         when UC.meeting_status = 'submitted' and (date_diff('second', date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end

                  ) >= 900)then 'successful'

         else 'unsuccessful'
         end AS MEETINGSTATUS,
         PM."partner_name" as "Partner Name",
         UC."meeting_date" as "Meeting Date",
         split_part(UC."meeting_start_timestamp",'T',2) as "Meeting Time",
         AMD."emp_id" as "Emp Id",
         AMD."employee_name" as "Name",
         FAV."band" as "Emp Band",
         FAV."is_fls" as "Is Fls",
         FAV."l1_code" as "L1 Id",
         FAV."l1_name" as "L1 Name",
         FAV."l2_code" as "L2 Id",
         FAV."l2_name" as "L2 Name",
         FAV."l3_code" as "L3 Id",
         FAV."l3_name" as "L3 Name",
         AMD."person_met" as "Person Met",
         AMD."designation" as "Designation",
         'HDFC Sales CP' as "Vertical",
         AMD."sub_vertical" as "Sub Vertical",
         AMD."location" as "Location",
         PM."state" as "State Name",
         '' as "Branch Name",
         AMD."unit_penetration_home_loans_last_month" as "No of Home Loan Files Disbursed Last Month",
    AMD."unit_penetration_cp_last_month" as "No of CP Sourced last month",
    AMD."unit_penetration_last_month" as "Unit Penetration Last Month",
    AMD."unit_penetration_home_loans_current_month" as "No of Home Loan Files Disbursed in current  Month",
    AMD."unit_penetration_cp_current_month" as "No of CP Sourced in current month",
    AMD."unit_penetration_current_month" as "Unit Penetration in current Month",
    AMD."unit_penetration_growth_actionable" as "Unit Penetration Growth/ De-growth/ Actionable",
    AMD."value_penetration_last_month" as "VP Last Month",
    AMD."value_penetration_current_month" as "VP Current Month",
    AMD."value_penetration_growth" as "Value Penetration Growth/ De-growth/ Actionable",
    AMD."tenure_ratio_last_month" as "Tenure Ratio Last Month",
    AMD."tenure_ratio_current_month" as "Tenure Ratio Current Month",
    AMD."tenure_ratio_growth" as "Tenure Ratio Growth/ De-growth/ Actionable",
    AMD."sum_assured_last_month" as "Sum Assured Ratio last Month",
    AMD."sum_assured_current_month" as "Sum Assured Ratio Current Month",
    AMD."sum_assured_growth" as "Sum Assured Growth/ De-growth/ Actionable",
    AMD."critical_illness_last_month" as "CI Rider attachment Last Month",
    AMD."critical_illness_current_month" as "CI Rider attachment Current  Month",
    AMD."critical_illness_growth" as "CI Growth/ De-growth/ Actionable",
    AMD."adb_rider_last_month" as "ADB Rider attachment Last Month",
    AMD."adb_rider_current_month" as "ADB Rider attachment Current Month",
    AMD."adb_rider_growth" as "ADB Growth/ De-growth/ Actionable",
    AMD."total_rider_last_month" as "Total Rider attachment last Month",
    AMD."total_rider_current_month" as "Total Rider attachment Current Month",
    AMD."total_rider_growth" as "Total Rider Growth/ De-growth/ Actionable",
    AMD."underwriting_cases_pending_sales" as "Underwriting cases pending with Sales as on date",
    AMD."underwriting_timeline_closure" as "Underwriting Timeline for Closure",
    AMD."underwriting_cases_pending" as "Underwriting cases pending with HDFC Life UW Team as on date",
    AMD."underwriting_timeline_decision" as "Underwriting Timeline for decision",
    AMD."claims_cases_pending_sales" as "Claim cases pending with Sales as on date",
    AMD."claims_timeline_closure" as "Claim Timeline for closure",
    AMD."claims_cases_pending" as "Claim cases pending with HDFC Life Group Claims Team as on date",
    AMD."claims_timeline_decision" as "Claim Timeline for decision",
    AMD."prarambh_training" as "How many Prarambh Training Conducted",
    AMD."prarambh_people" as "How many people covered",
    AMD."marketing_collateral_availability" as "Availability of marketing collateral in branch",
    AMD."remark" as "Remark",
    AMD."event_id" as "Event ID"
    from annexure_meeting_data_flatten_hdfc_sales as AMD
    Left join h1_fls_app_version as FAV on FAV."user_id"=AMD."emp_id"
  Left join instago_prod_h1_user_calendar as UC on UC."event_id"=AMD."event_id"
  Left join instago_prod_h1_partner_master as PM on PM."partner_id"=AMD."partner_id"
  where (TRY(date_trunc('month',date_parse(UC.meeting_date,'%Y%m%d'))) =TRY(date_trunc('month',current_date - interval '1' day))  
  and TRY(date_trunc('year',date_parse(UC.meeting_date,'%Y%m%d'))) = date_trunc('year',current_date - interval '1' day)))as res
####################Select 
 res."Emp Id",
 res."Name",
 res."Emp Band",
 res."Is Fls",
 res."L1 Id",
 res."L1 Name",
 res."L2 Id",
 res."L2 Name",
 res."L3 Id",
 res."L3 Name",
 res."Channel",
 res."Sub Channel",
 res."Partner Id",
 res."Partner",
 res."Partner Name",
 res."State Name",
 res."Branch Name",
 res."Meeting Date",
 res."Meeting Time",
 res."START_TIME",
 res."END_TIME",
case when res.ts <= 0 then ' ' else
         lpad(cast(abs(floor(date_diff('second', sttime,ettime)/3600)) as varchar),2,'0')||':'||
lpad(cast(abs(floor(date_diff('second', sttime,ettime)/60)-floor(date_diff('second', sttime,ettime)/3600)*60) as varchar),2,'0')||':'||
lpad(cast(mod(date_diff('second', sttime,ettime),60) as varchar),2,'0')
         end as
"TimeSpent (HH:MM:SS)",
 res."MEETINGSTATUS",
 res."Person Met",
 res."Designation",
 res."Vertical",
 res."Sub Vertical",
res."Location",
res."LAP No of Loan Files Disbursed Last Month",
res."PL No of Loan Files Disbursed Last Month",
res."CV No of Loan Files Disbursed Last Month",
res."Total No of Loan Files Disbursed Last Month",
res."LAP No of CP Sourced last month",
res."PL No of CP Sourced last month",
res."CV No of CP Sourced last month",
res."Total No of CP Sourced last month",
res."LAP Unit Penetration Last Month",
res."PL Unit Penetration Last Month",
res."CV Unit Penetration Last Month",
res."Total Unit Penetration Last Month",
res."LAP No of Loan Files Disbursed Current Month",
res."PL No of Loan Files Disbursed Current Month",
res."CV No of Loan Files Disbursed Current Month",
res."Total No of Loan Files Disbursed Current Month",
res."LAP No of CP Sourced Current month",
res."PL No of CP Sourced Current month",
res."CV No of CP Sourced Current month",
res."Total No of CP Sourced Current month",
res."LAP Unit Penetration Current Month",
res."PL Unit Penetration Current Month",
res."CV Unit Penetration Current Month",
res."Total Unit Penetration Current Month",
res."LAP Growth/ De-growth UP",
res."PL Growth/ De-growth UP",
res."CV Growth/ De-growth UP ",
res."Total Growth/ De-growth UP",
res."LAP Actionable UP",
res."PL Actionable UP",
res."CV Actionable UP",
res."Total Actionable UP",
res."LAP VP Last Month",
res."PL VP Last Month",
res."CV VP Last Month",
res."Total VP Last Month",
res."LAP VP Current Month",
res."PL VP Current Month",
res."CV VP Current Month",
res."Total VP Current Month",
res."LAP Growth/ De-growth VP",
res."PL Growth/ De-growth VP",
res."CV Growth/ De-growth VP",
res."Total Growth/ De-growth VP",
res."LAP Actionable VP",
res."PL Actionable VP",
res."CV Actionable VP",
res."Total Actionable VP",
res."LAP Tenure Ratio Last Month",
res."PL Tenure Ratio Last Month",
res."CV Tenure Ratio Last Month",
res."Total Tenure Ratio Last Month",
res."LAP Tenure Ratio Current Month",
res."PL Tenure Ratio Current Month",
res."CV Tenure Ratio Current Month",
res."Total Tenure Ratio Current Month",
res."LAP Growth/ De-growth TR",
res."PL Growth/ De-growth TR",
res."CV Growth/ De-growth TR",
res."Total Growth/ De-growth TR",
res."LAP Actionable TR",
res."PL Actionable TR",
res."CV Actionable TR",
res."Total Actionable TR",
res."LAP Sum Assured Ratio last Month",
res."PL Sum Assured Ratio last Month",
res."CV Sum Assured Ratio last Month",
res."Total Sum Assured Ratio last Month",
res."LAP Sum Assured Ratio Current Month",
res."PL Sum Assured Ratio Current Month",
res."CV Sum Assured Ratio Current Month",
res."Total Sum Assured Ratio Current Month",
res."LAP Growth/ De-growth SAR",
res."PL Growth/ De-growth SAR",
res."CV Growth/ De-growth SAR",
res."Total Growth/ De-growth SAR",
res."LAP Actionable SAR",
res."PL Actionable SAR",
res."CV Actionable SAR",
res."Total Actionable SAR",
res."LAP ADB Rider attachment Last Month",
res."PL ADB Rider attachment Last Month",
res."CV ADB Rider attachment Last Month",
res."Total ADB Rider attachment Last Month",
res."LAP ADB Rider attachment Current Month",
res."PL ADB Rider attachment Current Month",
res."CV ADB Rider attachment Current Month",
res."Total ADB Rider attachment Current Month",
res."LAP Growth/ De-growth ADB",
res."PL Growth/ De-growth ADB",
res."CV Growth/ De-growth ADB",
res."Total Growth/ De-growth ADB",
res."LAP Actionable ADB",
res."PL Actionable ADB",
res."CV Actionable ADB",
res."Total Actionable ADB",
res."LAP Underwriting cases pending with Sales as on date",
res."PL Underwriting cases pending with Sales as on date",
res."CV Underwriting cases pending with Sales as on date",
res."Total Underwriting cases pending with Sales as on date",
res."LAP Time line for closure with Sales",
res."PL Time line for closure with Sales",
res."CV Time line for closure with Sales",
res."Total Time line for closure with Sales",
res."LAP Underwriting cases pending with HDFC Life UW Team as on date",
res."PL Underwriting cases pending with HDFC Life UW Team as on date",
res."CV Underwriting cases pending with HDFC Life UW Team as on date",
res."Total Underwriting cases pending with HDFC Life UW Team as on date",
res."LAP Time line for decision",
res."PL Time line for decision",
res."CV Time line for decision",
res."Total Time line for decision",
res."LAP Claim cases pending with Sales as on date",
res."PL Claim cases pending with Sales as on date",
res."CV Claim cases pending with Sales as on date",
res."Total Claim cases pending with Sales as on date",
res."LAP Time line for closure Claim",
res."PL Time line for closure Claim",
res."CV Time line for closure Claim",
res."Total Time line for closure Claim",
res."LAP Claim cases pending with HDFC Life Group Claims Team as on date",
res."PL Claim cases pending with HDFC Life Group Claims Team as on date",
res."CV Claim cases pending with HDFC Life Group Claims Team as on date",
res."Total Claim cases pending with HDFC Life Group Claims Team as on date",
res."LAP Time line for closure Claim with HDFC",
res."PL Time line for closure Claim with HDFC",
res."CV Time line for closure Claim with HDFC",
res."Total Time line for closure Claim with HDFC",
res."LAP How many UDAAN Training Conducted",
res."PL How many UDAAN Training Conducted",
res."CV How many UDAAN Training Conducted",
res."Total How many UDAAN Training Conducted",
res."LAP How many people covered",
res."PL How many people covered",
res."CV How many people covered",
res."Total How many people covered",
res."LAP Availability of marketing collateral in branch",
res."PL Availability of marketing collateral in branch",
res."CV Availability of marketing collateral in branch",
res."Total Availability of marketing collateral in branch",
res."LAP Remark",
res."PL Remark",
res."CV Remark",
res."Total Remark",
res."Event ID"
From(SELECT
    FAV."channel" as "Channel",
    FAV."sub_channel" as "Sub Channel",
    AMD."partner_id" as "Partner Id",
    PM."partner" as "Partner",
    UC."meeting_start_time" as "START_TIME",
    UC."meeting_end_time" as "END_TIME",
    date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p') as sttime,
  case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end as ettime,
    date_diff('second', date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end

                  ) as ts,
  case when UC.meeting_status = 'started' then 'ongoing'

  when UC.meeting_status = 'ended' and (date_diff('second', date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end

                  ) >= 900)then 'successful'

         when UC.meeting_status = 'submitted' and (date_diff('second', date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when UC.meeting_end_time = '00:00' then
          date_parse(UC.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when UC.meeting_end_time = '' then
         date_parse(UC.meeting_date||UC.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(UC.meeting_date||UC.meeting_end_time,'%Y%m%d%h:%i %p') end

                  ) >= 900)then 'successful'

         else 'unsuccessful'
         end AS MEETINGSTATUS,
         PM."partner_name" as "Partner Name",
         UC."meeting_date" as "Meeting Date",
         split_part(UC."meeting_start_timestamp",'T',2) as "Meeting Time",
         AMD."emp_id" as "Emp Id",
         AMD."employee_name" as "Name",
         FAV."band" as "Emp Band",
         FAV."is_fls" as "Is Fls",
         FAV."l1_code" as "L1 Id",
         FAV."l1_name" as "L1 Name",
         FAV."l2_code" as "L2 Id",
         FAV."l2_name" as "L2 Name",
         FAV."l3_code" as "L3 Id",
         FAV."l3_name" as "L3 Name",
         AMD."person_met" as "Person Met",
         AMD."designation" as "Designation",
         'HDFC Sales CP' as "Vertical",
         AMD."sub_vertical" as "Sub Vertical",
         AMD."location" as "Location",
         PM."state" as "State Name",
         '' as "Branch Name",
    AMD."up_lap_loan_files_disbursed_last_month" as "LAP No of Loan Files Disbursed Last Month",
    AMD."up_pl_loan_files_disbursed_last_month" as "PL No of Loan Files Disbursed Last Month",
    AMD."up_cv_loan_files_disbursed_last_month" as "CV No of Loan Files Disbursed Last Month",
    AMD."up_total_loan_files_disbursed_last_month" as "Total No of Loan Files Disbursed Last Month",
    AMD."up_lap_cp_sourced_last_month" as "LAP No of CP Sourced last month",
    AMD."up_pl_cp_sourced_last_month" as "PL No of CP Sourced last month",
    AMD."up_cv_cp_sourced_last_month" as "CV No of CP Sourced last month",
    AMD."up_total_cp_sourced_last_month" as "Total No of CP Sourced last month",
    AMD."up_lap_up_last_month" as "LAP Unit Penetration Last Month",
    AMD."up_pl_up_last_month" as "PL Unit Penetration Last Month",
    AMD."up_cv_up_last_month" as "CV Unit Penetration Last Month",
    AMD."up_total_up_last_month" as "Total Unit Penetration Last Month",
    AMD."up_lap_loan_files_disbursed_current_month" as "LAP No of Loan Files Disbursed Current Month",
    AMD."up_pl_loan_files_disbursed_current_month" as "PL No of Loan Files Disbursed Current Month",
    AMD."up_cv_loan_files_disbursed_current_month" as "CV No of Loan Files Disbursed Current Month",
    AMD."up_total_loan_files_disbursed_current_month" as "Total No of Loan Files Disbursed Current Month",
    AMD."up_lap_cp_sourced_current_month" as "LAP No of CP Sourced Current month",
    AMD."up_pl_cp_sourced_current_month" as "PL No of CP Sourced Current month",
    AMD."up_cv_cp_sourced_current_month" as "CV No of CP Sourced Current month",
    AMD."up_total_cp_sourced_current_month" as "Total No of CP Sourced Current month",
    AMD."up_lap_up_current_month" as "LAP Unit Penetration Current Month",
    AMD."up_pl_up_current_month" as "PL Unit Penetration Current Month",
    AMD."up_cv_up_current_month" as "CV Unit Penetration Current Month",
    AMD."up_total_up_current_month" as "Total Unit Penetration Current Month",
    AMD."up_lap_growth" as "LAP Growth/ De-growth UP",
    AMD."up_pl_growth" as "PL Growth/ De-growth UP",
    AMD."up_cv_growth" as "CV Growth/ De-growth UP ",
    AMD."up_total_growth" as "Total Growth/ De-growth UP",
    AMD."up_lap_actionable" as "LAP Actionable UP",
    AMD."up_pl_actionable" as "PL Actionable UP",
    AMD."up_cv_actionable" as "CV Actionable UP",
    AMD."up_total_actionable" as "Total Actionable UP",
    AMD."vp_lap_last_month" as "LAP VP Last Month",
    AMD."vp_pl_last_month" as "PL VP Last Month",
    AMD."vp_cv_last_month" as "CV VP Last Month",
    AMD."vp_total_last_month" as "Total VP Last Month",
    AMD."vp_lap_current_month" as "LAP VP Current Month",
    AMD."vp_pl_current_month" as "PL VP Current Month",
    AMD."vp_cv_current_month" as "CV VP Current Month",
    AMD."vp_total_current_month" as "Total VP Current Month",
    AMD."vp_lap_growth" as "LAP Growth/ De-growth VP",
    AMD."vp_pl_growth" as "PL Growth/ De-growth VP",
    AMD."vp_cv_growth" as "CV Growth/ De-growth VP",
    AMD."vp_total_growth" as "Total Growth/ De-growth VP",
    AMD."vp_lap_actionable" as "LAP Actionable VP",
    AMD."vp_pl_actionable" as "PL Actionable VP",
    AMD."vp_cv_actionable" as "CV Actionable VP",
    AMD."vp_total_actionable" as "Total Actionable VP",
    AMD."tr_lap_last_month" as "LAP Tenure Ratio Last Month",
    AMD."tr_pl_last_month" as "PL Tenure Ratio Last Month",
    AMD."tr_cv_last_month" as "CV Tenure Ratio Last Month",
    AMD."tr_total_last_month" as "Total Tenure Ratio Last Month",
    AMD."tr_lap_current_month" as "LAP Tenure Ratio Current Month",
    AMD."tr_pl_current_month" as "PL Tenure Ratio Current Month",
    AMD."tr_cv_current_month" as "CV Tenure Ratio Current Month",
    AMD."tr_total_current_month" as "Total Tenure Ratio Current Month",
    AMD."tr_lap_growth" as "LAP Growth/ De-growth TR",
    AMD."tr_pl_growth" as "PL Growth/ De-growth TR",
    AMD."tr_cv_growth" as "CV Growth/ De-growth TR",
    AMD."tr_total_growth" as "Total Growth/ De-growth TR",
    AMD."tr_lap_actionable" as "LAP Actionable TR",
    AMD."tr_pl_actionable" as "PL Actionable TR",
    AMD."tr_cv_actionable" as "CV Actionable TR",
    AMD."tr_total_actionable" as "Total Actionable TR",
    AMD."sar_lap_last_month" as "LAP Sum Assured Ratio last Month",
    AMD."sar_pl_last_month" as "PL Sum Assured Ratio last Month",
    AMD."sar_cv_last_month" as "CV Sum Assured Ratio last Month",
    AMD."sar_total_last_month" as "Total Sum Assured Ratio last Month",
    AMD."sar_lap_current_month"  as "LAP Sum Assured Ratio Current Month",
    AMD."sar_pl_current_month" as "PL Sum Assured Ratio Current Month",
    AMD."sar_cv_current_month" as "CV Sum Assured Ratio Current Month",
    AMD."sar_total_current_month" as "Total Sum Assured Ratio Current Month",
    AMD."sar_lap_growth" as "LAP Growth/ De-growth SAR",
    AMD."sar_pl_growth" as "PL Growth/ De-growth SAR",
    AMD."sar_cv_growth" as "CV Growth/ De-growth SAR",
    AMD."sar_total_growth" as "Total Growth/ De-growth SAR",
    AMD."sar_lap_actionable" as "LAP Actionable SAR",
    AMD."sar_pl_actionable" as "PL Actionable SAR",
    AMD."sar_cv_actionable" as "CV Actionable SAR",
    AMD."sar_total_actionable" as "Total Actionable SAR",
    AMD."adb_attachment_lap_last_month" as "LAP ADB Rider attachment Last Month",
    AMD."adb_attachment_pl_last_month" as "PL ADB Rider attachment Last Month",
    AMD."adb_attachment_cv_last_month" as "CV ADB Rider attachment Last Month",
    AMD."adb_attachment_total_last_month"  as "Total ADB Rider attachment Last Month",
    AMD."adb_attachment_lap_current_month"  as "LAP ADB Rider attachment Current Month",
    AMD."adb_attachment_pl_current_month"  as "PL ADB Rider attachment Current Month",
    AMD."adb_attachment_cv_current_month"  as "CV ADB Rider attachment Current Month",
    AMD."adb_attachment_total_current_month"  as "Total ADB Rider attachment Current Month",
    AMD."adb_lap_growth" as "LAP Growth/ De-growth ADB", 
    AMD."adb_pl_growth" as "PL Growth/ De-growth ADB",
    AMD."adb_cv_growth" as "CV Growth/ De-growth ADB",
    AMD."adb_total_growth" as "Total Growth/ De-growth ADB",
    AMD."adb_lap_actionable" as "LAP Actionable ADB",
    AMD."adb_pl_actionable" as "PL Actionable ADB",
    AMD."adb_cv_actionable" as "CV Actionable ADB",
    AMD."adb_total_actionable" as "Total Actionable ADB",
    AMD."ur_lap_case_pending_sales" as "LAP Underwriting cases pending with Sales as on date",
    AMD."ur_pl_case_pending_sales" as "PL Underwriting cases pending with Sales as on date",
    AMD."ur_cv_case_pending_sales" as "CV Underwriting cases pending with Sales as on date",
    AMD."ur_total_case_pending_sales" as "Total Underwriting cases pending with Sales as on date",
    AMD."ur_lap_case_timeline_for_closure" as "LAP Time line for closure with Sales",
    AMD."ur_pl_case_timeline_for_closure" as "PL Time line for closure with Sales",
    AMD."ur_cv_case_timeline_for_closure" as "CV Time line for closure with Sales",
    AMD."ur_total_timeline_for_closure" as "Total Time line for closure with Sales",
    AMD."ur_lap_case_pending_hdfc" as "LAP Underwriting cases pending with HDFC Life UW Team as on date",
    AMD."ur_pl_case_pending_hdfc" as "PL Underwriting cases pending with HDFC Life UW Team as on date",
    AMD."ur_cv_case_pending_hdfc" as "CV Underwriting cases pending with HDFC Life UW Team as on date",
    AMD."ur_total_case_pending_hdfc" as "Total Underwriting cases pending with HDFC Life UW Team as on date",
    AMD."ur_lap_case_timeline_for_decision" as "LAP Time line for decision",
    AMD."ur_pl_case_timeline_for_decision" as "PL Time line for decision",
    AMD."ur_cv_case_timeline_for_decision" as "CV Time line for decision",
    AMD."ur_total_timeline_for_decision" as "Total Time line for decision",
    AMD."claims_lap_case_pending_sales" as "LAP Claim cases pending with Sales as on date",
    AMD."claims_pl_case_pending_sales" as "PL Claim cases pending with Sales as on date",
    AMD."claims_cv_case_pending_sales" as "CV Claim cases pending with Sales as on date",
    AMD."claims_total_case_pending_sales" as "Total Claim cases pending with Sales as on date",
    AMD."claims_lap_case_timeline_for_closure" as "LAP Time line for closure Claim",
    AMD."claims_pl_case_timeline_for_closure" as "PL Time line for closure Claim",
    AMD."claims_cv_case_timeline_for_closure" as "CV Time line for closure Claim",
    AMD."claims_total_timeline_for_closure" as "Total Time line for closure Claim",
    AMD."claims_lap_case_pending_hdfc" as "LAP Claim cases pending with HDFC Life Group Claims Team as on date",
    AMD."claims_pl_case_pending_hdfc" as "PL Claim cases pending with HDFC Life Group Claims Team as on date",
    AMD."claims_cv_case_pending_hdfc" as "CV Claim cases pending with HDFC Life Group Claims Team as on date",
    AMD."claims_total_case_pending_hdfc" as "Total Claim cases pending with HDFC Life Group Claims Team as on date",
    AMD."claims_lap_case_timeline_for_decision" as "LAP Time line for closure Claim with HDFC",
    AMD."claims_pl_case_timeline_for_decision" as "PL Time line for closure Claim with HDFC",
    AMD."claims_cv_case_timeline_for_decision" as "CV Time line for closure Claim with HDFC",
    AMD."claims_total_timeline_for_decision" as "Total Time line for closure Claim with HDFC",
    AMD."udaan_lap_training_conducted" as "LAP How many UDAAN Training Conducted",
    AMD."udaan_pl_training_conducted" as "PL How many UDAAN Training Conducted",
    AMD."udaan_cv_training_conducted" as "CV How many UDAAN Training Conducted",
    AMD."udaan_total_training_conducted" as "Total How many UDAAN Training Conducted", 
    AMD."udaan_lap_people_covered" as "LAP How many people covered",
    AMD."udaan_pl_people_covered" as "PL How many people covered",
    AMD."udaan_cv_people_covered" as "CV How many people covered",
    AMD."udaan_total_people_covered" as "Total How many people covered",
    AMD."mc_lap_availability" as "LAP Availability of marketing collateral in branch",
    AMD."mc_pl_availability" as "PL Availability of marketing collateral in branch",
    AMD."mc_cv_availability" as "CV Availability of marketing collateral in branch",
    AMD."mc_total_availability" as "Total Availability of marketing collateral in branch",
    AMD."remark_lap" as "LAP Remark", 
    AMD."remark_pl" as "PL Remark",
    AMD."remark_cv" as "CV Remark",
    AMD."remark_total" as "Total Remark",
    AMD."event_id" as "Event ID"
    from annexure_meeting_data_annexure_hdb_fin as AMD
    Left join h1_fls_app_version as FAV on FAV."user_id"=AMD."emp_id"
  Left join instago_prod_h1_user_calendar as UC on UC."event_id"=AMD."event_id"
  Left join instago_prod_h1_partner_master as PM on PM."partner_id"=AMD."partner_id"
  where (TRY(date_trunc('month',date_parse(UC.meeting_date,'%Y%m%d'))) =TRY(date_trunc('month',current_date - interval '1' day))  
  and TRY(date_trunc('year',date_parse(UC.meeting_date,'%Y%m%d'))) = date_trunc('year',current_date - interval '1' day)))as res####################SELECT 
c.user_id as "USER ID",
fv.user_name as "USER NAME",
fv.band as "EMPLOYEE BAND",
fv.channel as "Channel",
fv.is_fls as "IS FLS",
c.aggregate_id as "EVENT ID",
c.partner_id as "PARTNER ID",
cast(from_iso8601_timestamp(c.record_last_updated) as date) as "DATE",
date_format(date_parse(c."record_last_updated",'%Y-%m-%dT%H:%i:%s.%fZ'),'%H:%i') as "TIME",
c.dts_data_cms as "CUSTOMER MEETING",
c.dts_data_pm as "PARTNER ENGAGEMENT",
c.dts_data_ts as "TRAINING SESSIONS",
c.dts_data_roe as "R&R AND OTHER EVENT",
c.dts_data_pr as "PARTNER REVIEW",
c.dts_data_other as "OTHER"
FROM 
"instago_mis"."instago_prod_h1_dts_data_aggregate" as c
LEFT Join
"instago_mis"."h1_fls_app_version" as fv on (c.user_id = fv.user_id)
WHERE c.dts_type = 'FTD' AND fv.channel LIKE 'Bancassurance IDFC%'  AND 
(TRY(date_trunc('month',date_parse(c."record_last_updated",'%Y-%m-%dT%H:%i:%s.%fZ'))) =TRY(date_trunc('month',current_timestamp - interval '1' day))  and TRY(date_trunc('year',date_parse(c."record_last_updated",'%Y-%m-%dT%H:%i:%s.%fZ'))) = date_trunc('year',current_date - interval '1' day))
####################Select
UC.lead_id As "Lead id", UC.name AS "Lead name", UC.lead_worksite_code As "Unique code", UC.lead_contact As "Mobile", 
UC.meeting_date As "Date of creation", WC.worksite_type As "Worksite Type", WC.location As "Location", 
WC.No_Of_Lecture_Attendees As "No of attendees", UC.lead_status As "Status", WC.fls_name As "FLS Name", 
UC.meeting_date As "Conversion date" FROM "instago_mis"."h1_user_calendar" AS UC 
INNER JOIN "instago_mis"."h1_worksite_code" AS WC ON UC.lead_worksite_code = WC.unique_lecture_code 
WHERE (TRY(date_trunc('month',date_parse(UC.meeting_date,'%Y%m%d'))) =TRY(date_trunc('month',current_date - interval '1' day)) and
TRY(date_trunc('year',date_parse(UC.meeting_date,'%Y%m%d'))) = date_trunc('year',current_date - interval '1' day))
####################select
res.user_name as "Employee Name",
res.band as "Employee Band",
res.is_fls as "Is FLS",
res.CHANNEL as CHANNEL,
res.SUBCHANNEL as SUBCHANNEL,
         res.PARTNERID as PARTNERID,
         res.Partner AS Partner,
         res.Partner_Type AS Partner_Type,
         res.SERVER_DATE as SERVER_DATE,
         case when ts <= 0 then ' ' else cast(ts as varchar) end as TIMESPENT,
         res.ADDRESS as ADDRESS,
         res.CITY as CITY,
         res.PARTNERPINCODE as PARTNERPINCODE,
         res.USERID as USERID,
         res.submit_time as SubmittedTime,
         res.START_TIME as START_TIME,
         res.END_TIME as END_TIME,
         case when ts <= 0 then ' ' else
         lpad(cast(abs(floor(date_diff('second', sttime,ettime)/3600)) as varchar),2,'0')||':'||
lpad(cast(abs(floor(date_diff('second', sttime,ettime)/60)-floor(date_diff('second', sttime,ettime)/3600)*60) as varchar),2,'0')||':'||
lpad(cast(mod(date_diff('second', sttime,ettime),60) as varchar),2,'0')
         end as
"TimeSpent (HH:MM:SS)",
         res.MEETINGSTATUS as MEETINGSTATUS,
         -- res.ms as ms,
         res.EMPLOYEE_FLAG as EMPLOYEE_FLAG,
         res.PARTNERNAME as PARTNERNAME,
         res.START_DATE as START_DATE,
         res.END_DATE as END_DATE,
         res.ANNEXURE_FILLED as ANNEXURE_FILLED,
         res.LAT as LAT,
         res."LONG" as "LONG",
         res.EventId
         
from (
SELECT p.channel_name AS CHANNEL,
        FA.user_name,
        FA.band,
        FA.is_fls,
         p.sub_channel_name AS SUBCHANNEL,
         p.partner_id AS PARTNERID,
         p.partner AS Partner,
         p.partner_type AS Partner_Type,
         c.meeting_date AS SERVER_DATE,
         c.meeting_status AS ms,
         date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p') as sttime,
         case when c.meeting_end_time = '00:00' then
          date_parse(c.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when c.meeting_end_time = '' then
         date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(c.meeting_date||c.meeting_end_time,'%Y%m%d%h:%i %p') end as ettime,
         -- '0' AS TIMESPENT,
         '' AS ADDRESS,
         p.city AS CITY,
         '' AS PARTNERPINCODE,
 
         date_diff('second', date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when c.meeting_end_time = '00:00' then
          date_parse(c.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when c.meeting_end_time = '' then
         date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(c.meeting_date||c.meeting_end_time,'%Y%m%d%h:%i %p') end
                 
                  ) as ts,
 
         a.user_id AS USERID,
         c.meeting_start_time AS START_TIME,
         c.meeting_end_time AS END_TIME,
         c.submit_time as submit_time,
         -- '0' AS TIMESPENT_HH,
         case when c.meeting_status = 'started' then 'ongoing'
 
  when c.meeting_status = 'ended' and (date_diff('second', date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when c.meeting_end_time = '00:00' then
          date_parse(c.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when c.meeting_end_time = '' then
         date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(c.meeting_date||c.meeting_end_time,'%Y%m%d%h:%i %p') end
                 
                  ) >= 900)then 'successful'
   
         when c.meeting_status = 'submitted' and (date_diff('second', date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p'),
                   case when c.meeting_end_time = '00:00' then
          date_parse(c.meeting_date||'12:00 AM','%Y%m%d%h:%i %p')
         when c.meeting_end_time = '' then
         date_parse(c.meeting_date||c.meeting_start_time,'%Y%m%d%h:%i %p')
         else
         date_parse(c.meeting_date||c.meeting_end_time,'%Y%m%d%h:%i %p') end
                 
                  ) >= 900)then 'successful'
 
         else 'unsuccessful'
         end AS MEETINGSTATUS,
         '' AS EMPLOYEE_FLAG,
         p.partner_name AS PARTNERNAME,
         c.meeting_date AS START_DATE,
         c.meeting_date AS END_DATE,
         a.annexure_data_present AS ANNEXURE_FILLED,
         p.partner_gps_lat AS LAT,
         p.partner_gps_long AS "LONG",
         a.event_id as EventId
FROM instago_prod_h1_partner_master AS p
LEFT JOIN instago_prod_h1_annexure_meeting_data AS a
    ON a.partner_id = p.partner_id
LEFT JOIN instago_prod_h1_user_calendar AS c
    ON a.event_id = c.event_id
LEFT JOIN h1_fls_app_version AS FA ON a.user_id = FA.user_id
   where c.meeting_type = 'Partner' and TRY(date_trunc('month',date_parse(c.meeting_date,'%Y%m%d'))) =TRY(date_trunc('month',current_date - interval '1' day)) and c.meeting_status != 'draft' and p.channel_name NOT LIKE 'Direct%'
   ) as res
####################FC_Attendance_Report_Monthly_,ABP_Attendance_Report_Monthly_,MIS_Annexure_IDFC_Bank_Monthly_,Lead_Login_Logs_Consolidated_Monthly_,MIS_HDFC_Sales_CP_Monthly_,MIS_HDB_Fin_CP_Monthly_,MIS_DTS_IDFC_Bank_Monthly_,MIS_Shaurya_Worksite_Lead_Monthly_,MIS_partner_visit_BI_,
####################fc-attendance-report-monthly,abp-attendance-report-monthly,MIS_Annexure_IDFC_Bank_Monthly,lead-login-usage-data-report-monthly,MIS_HDFC_Sales_CP_Monthly,MIS_HDB_Fin_CP_Monthly,MIS_DTS_IDFC_Bank,MIS_Shaurya_Worksite_Lead_Monthly,mis-partner-visit,
"""

def lambda_handler(event, context):
    query_list = queries.split('####################')
    
    names = query_list[-2].split(',')
    names = names[:-1]
    output_folder = query_list[-1].split(',')
    output_folder = output_folder[:-1]
    for ind,query in enumerate(query_list[:-2]):
        mis_sharing_list=['MIS_partner_visit_BI_']
        RESULT_FOLDER = "MIS/"+output_folder[ind]
        Name = names[ind]
        dest_file_name = f"{RESULT_FOLDER}/{Name}{DAY}{MONTH}{YEAR}.csv"
        if Name in mis_sharing_list:
            RESULT_FOLDER = "MIS_sharing/"+output_folder[ind]
            dest_file_name = f"{RESULT_FOLDER}/{Name}{PreMONTH}{PreYEAR}.csv"

        response = client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={'Database': ATHENA_DB},
            ResultConfiguration={'OutputLocation': f"s3://{S3_BUCKET}/{RESULT_FOLDER}"}
        )
            
        temp_file_name = Name+DAY+MONTH+YEAR
        print("temp_file_name:",temp_file_name)
        query_execution_id = response['QueryExecutionId']
        source_file_name = f"{S3_BUCKET}/{RESULT_FOLDER}/{query_execution_id}.csv"
        if Name in mis_sharing_list:
            temp_file_name = Name+PreMONTH+PreYEAR
        dest_file_name = f"{RESULT_FOLDER}/"+temp_file_name+".csv"
        print("dest_file_name:",dest_file_name)
        
        for i in range(1, 1 + RETRY_COUNT):
            query_status = client.get_query_execution(QueryExecutionId=query_execution_id)

            query_execution_status = query_status['QueryExecution']['Status']['State']
    
            if query_execution_status == 'SUCCEEDED':
                print("STATUS:" + query_execution_status)
    
                # Rename the file
                s3.Object(S3_BUCKET, dest_file_name).copy_from(CopySource=source_file_name)
    
                # Deletes Athena generated csv and it's metadata file
                s3.Object(S3_BUCKET, f"{RESULT_FOLDER}/{query_execution_id}.csv").delete()
                s3.Object(S3_BUCKET, f"{RESULT_FOLDER}/{query_execution_id}.csv.metadata").delete()
                break

    
            if query_execution_status == 'FAILED':
                print("STATUS:" + query_execution_status)
            else:
                print("STATUS:" + query_execution_status)
                time.sleep(i)
        else:
            client.stop_query_execution(QueryExecutionId=query_execution_id)
            print('TIME OUT')
