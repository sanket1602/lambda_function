__author__ = 'siddharth.porwal@blazeclan.com'

import json
import boto3
import time
from os import getenv
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Key, Attr

# Env variables
# athena_database  : instago
# s3_bucket_name   : instago-uat-h1-athena-query-result
# s3_output_folder : lead-tracking-not-met

