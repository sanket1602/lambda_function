__author__ = 'siddharth.porwal@blazeclan.com'
====================================================
Test Lambda
====================================================
import json
import boto3
import time
from os import getenv
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Key, Attr

# Env variables
# athena_database  : instago
# s3_bucket_name   : instago-uat-h1-athena-query-result
# s3_output_folder : lead-tracking-not-met

ATHENA_DB = getenv("athena_database")
S3_BUCKET = getenv("s3_bucket_name")

RETRY_COUNT = 100

# AWS resources
s3 = boto3.resource("s3")
client = boto3.client('athena')

# Date string
YEAR = (datetime.today() + timedelta(hours=5.5)).strftime('%Y')
MONTH = (datetime.today() + timedelta(hours=5.5)).strftime('%b')
DAY = (datetime.today() + timedelta(hours=5.5)).strftime('%d')

queries = """
SELECT
    res.channel AS Channel,
    res.user_id AS User_id,
    date_format(date_parse(res.login_time,'%Y-%m-%dT%H:%i:%s.%fZ'),'%d/%m/%y %H:%i') AS Login_date

FROM (
    SELECT
        AL.user_id AS user_id,
        FA.channel AS channel,
        AL.event_time AS login_time

    FROM h1_app_login_logs  AS AL
        LEFT JOIN h1_fls_app_version  AS FA
            ON AL.user_id = FA.user_id
        WHERE AL.tokenstatus = 'SUCCESS' and 
        TRY(date_trunc('month',date_parse(event_time,'%Y-%m-%dT%H:%i:%s.%fZ'))) = date_trunc('month',current_date) and
        TRY(date_trunc('year',date_parse(event_time,'%Y-%m-%dT%H:%i:%s.%fZ'))) = date_trunc('year',current_date)

) AS res
####################
SELECT
    res.channel AS Channel,
    res.CRM_lead_id AS CRMLeadID,
    res.lead_name AS Fname,
    res.user_id AS Lead_Assigned_to_Code,
    res.lead_gps_lat AS Lead_Latitude,
    res.lead_gps_long AS Lead_Longitude,
    res.at_branch AS AtBranch,
    IF(res.at_branch='False', 'NA', res.branch_name) AS BranchName,
    res.lead_status AS Lead_Status,
    res.lead_contact AS Lead_Contact,
    IF(res.lg_id = res.lf_id , 'YES', 'NO') AS LeadSourceSLG,
    CASE
        WHEN res.lead_type = 'Grab' THEN
            'G'
        WHEN res.lead_type = 'Auto Allocate' THEN
            'A'
        ELSE
            'NA'
    END AS LeadType,
    TRY(date_format(date_parse(res.meeting_done_start_date||res.meeting_done_start_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Actual_Appointment_time,
    TRY(date_format(date_parse(res.meeting_end_date||res.meeting_end_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Meeting_End_Date_Time,
    TRY(date_format(date_parse(res.meeting_done_start_date||res.meeting_done_start_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Meeting_Start_Date_Time,
    TRY(ABS(date_diff('second',
        date_parse(res.meeting_done_start_date||res.meeting_done_start_time,'%Y%m%d%h:%i %p'),
        date_parse(res.meeting_end_date||res.meeting_end_time,'%Y%m%d%h:%i %p')
    )))AS TimeSpent,
    res.fls_id AS fls_id,
    res.pincode AS Pincode,
    res.city AS City,
    res.Campaign_Code AS Campaign_Code,
    res.state AS State,
    TRY(date_format(date_parse(res.meeting_date||res.meeting_schedule_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Meeting_Appointment_time,
    IF(res.meeting_status = 'Y', 'MET', 'NOT MET') AS Meeting_Status,
    res.instago_lead_id AS Geo_Lead_Id,
    res.address AS Address,
    res.lead_comments AS Lead_Comments,
    res.lead_sub_status AS Lead_Sub_Disposition_Status,
    res.meeting_notes AS Meeting_Comments,
    res.meeting_done_on AS Meeting_mode,
    CASE
        WHEN res.jointCallDoneFlag = 'True' THEN
            res.jointCallDoneFlag
        WHEN res.jointCallDoneFlag = 'False' THEN
            res.jointCallDoneFlag
        ELSE
            ''
    END AS jointMeetingDoneFlag,
    case when res.JointCallDoneWithL1UserId =  'True' then res.l1_code else '' end as JointMeetingDoneWithL1UserId,
    res.accept_reject_noti_sent_l1 As AcceptRejectNotificationSentL1,
    res.accept_reject_noti_sent_l1_dttm As AcceptRejectNotificationSentL1TimeStamp,
    res.JointCallWithL1SameLocation as JointMeetingWithL1SameLocation,
    res.JointCallL1Response as JointMeetingL1Response,
    case when res.JointCallDoneWithL2UserId =  'True' then res.l2_code else '' end as JointMeetingDoneWithL2UserId,
    res.accept_reject_noti_sent_l2 As AcceptRejectNotificationSentL2,
    res.accept_reject_noti_sent_l2_dttm As AcceptRejectNotificationSentL2TimeStamp,
    res.JointCallWithL2SameLocation as JointMeetingWithL2SameLocation,
    res.JointCallL2Response as JointMeetingL2Response
    
FROM (

SELECT
    FA.channel AS channel,
    FA.l1_code as l1_code,
    FA.l2_code as l2_code,
    FA.fls_id as fls_id,
    UC.event_id AS event_id,
    UC.lead_id AS CRM_lead_id,
    LD.lead_name AS lead_name,
    LD.lg_id AS lg_id,
    LD.lf_id AS lf_id,
    UC.lead_gps_lat AS lead_gps_lat,
    UC.lead_gps_long AS lead_gps_long,
    UC.at_branch AS at_branch,
    UC.branch_name AS branch_name,
    UC.lead_status AS lead_status,
    UC.meeting_type AS lead_type,
    UC.meeting_status AS meeting_status,
    UC.user_id AS user_id,
    LD1.lead_comments AS lead_comments,
    UC.address AS address,
    UC.accept_reject_noti_sent_l1,
    UC.accept_reject_noti_sent_l1_dttm,
    UC.accept_reject_noti_sent_l2,
    UC.accept_reject_noti_sent_l2_dttm,
    UC1.meeting_notes AS meeting_notes,
    LD.lead_sub_status AS lead_sub_status,
    UC.meeting_date AS meeting_date,
    UC.meeting_start_time AS meeting_schedule_time,
    UC.meeting_end_date AS meeting_end_date,
    UC.meeting_end_time AS meeting_end_time,
    UC.meeting_done_start_date AS meeting_done_start_date,
    UC.meeting_done_start_time AS meeting_done_start_time,
    UC.meeting_done_on AS meeting_done_on,
    '' AS instago_lead_id,
    UC.joint_call_along_with_l1 JointCallDoneWithL1UserId,
    UC.joint_call_along_with_l2 JointCallDoneWithL2UserId,
    IF((UC.joint_call_along_with_L1_same_loc = 'True' and UC.joint_call_L1_response = 'Accept') or (UC.joint_call_along_with_L2_same_loc = 'True' and UC.joint_call_L2_response = 'Accept'),'True',IF(UC.joint_call_along_with_L1_same_loc = '' and UC.joint_call_along_with_L2_same_loc = '','','False')) as jointCallDoneFlag,
    UC.joint_call_along_with_L1_same_loc As JointCallWithL1SameLocation,
    UC.joint_call_along_with_L2_same_loc As JointCallWithL2SameLocation,
    UC.joint_call_L1_response As JointCallL1Response,
    UC.joint_call_L2_response As JointCallL2Response,
    UC.lead_contact AS lead_contact,
    LD.lead_zipcode pincode,
    LD.lead_state state,
    LD.lead_city city,
    IF(LD.lead_sub_campaign_code='' or LD.lead_sub_campaign_code is NULL, LD.campaign_code, LD.lead_sub_campaign_code) AS Campaign_Code,
    FA.s_user_row_id as user_row_id,
    UC.CRM_lead_sync_status CRM_lead_sync_status
FROM h1_user_calendar AS UC 
LEFT Join h1_lead_details AS LD ON LD.CRM_lead_id  = UC.lead_id
LEFT Join h1_user_calendar_notes as UC1 on UC1.event_id = UC.event_id
LEFT JOIN h1_fls_app_version AS FA ON UC.user_id = FA.user_id
LEFT JOIN h1_lead_details_comments AS LD1 on LD1.CRM_lead_id = UC.lead_id
WHERE UC.meeting_date >= date_format((current_timestamp - interval '45' day),'%Y%m%d')
       AND UC.meeting_done_on = 'In-Person'
       OR UC.event_operation = 'Start Meeting'
       AND UC.meeting_type = 'Lead'
        AND UC.event_operation != ''
        AND UC.event_operation is not null
        and UC.CRM_lead_sync_status != 'Failed'
    ) AS res where lower(channel) like '%direct%' or lower(channel) like '%speciality%' or lower(channel) like '%protection%'
####################SELECT
    res.channel AS Channel,
    res.CRM_lead_id AS CRMLeadID,
    res.lead_name AS Fname,
    res.user_id AS Lead_Assigned_to_Code,
    res.lead_gps_lat AS Lead_Latitude,
    res.lead_gps_long AS Lead_Longitude,
    res.lead_status AS Lead_Status,
    CASE 
        WHEN LENGTH(res.lead_contact) >= 10 THEN 
            concat('XXXXXXXXX',SUBSTRING(res.lead_contact, 10, LENGTH(res.lead_contact))) 
    END AS Lead_Contact,
    IF(res.lg_id = res.lf_id , 'YES', 'NO') AS LeadSourceSLG,
    CASE
        WHEN res.lead_type = 'Grab' THEN
            'G'
        WHEN res.lead_type = 'Auto Allocate' THEN
            'A'
        ELSE
            'NA'
    END AS LeadType,
    TRY(date_format(date_parse(res.meeting_done_start_date||res.meeting_done_start_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Actual_Appointment_time,
    res.fls_id AS fls_id,
    res.pincode AS Pincode,
    res.city AS City,
    res.Campaign_Code AS Campaign_Code,
    res.state AS State,
    TRY(date_format(date_parse(res.meeting_date||res.meeting_schedule_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Meeting_Appointment_time,
    IF(res.meeting_status = 'Y', 'MET', 'NOT MET') AS Meeting_Status,
    res.instago_lead_id AS Geo_Lead_Id,
    res.address AS Address,
    res.lead_comments AS Lead_Comments,
    res.lead_sub_status AS Lead_Sub_Disposition_Status,
    res.meeting_notes AS Meeting_Comments,
    res.meeting_done_on AS Meeting_mode,
    res.jointCallDoneFlag as JointMeetingDoneFlag,
    case when res.JointCallDoneWithL1UserId =  'True' then res.l1_code else '' end as JointMeetingDoneWithL1UserId,
    case when res.JointCallDoneWithL2UserId =  'True' then res.l2_code else '' end as JointMeetingDoneWithL2UserId
    
FROM (

SELECT
    FA.channel AS channel,
    FA.l1_code as l1_code,
    FA.l2_code as l2_code,
    FA.fls_id as fls_id,
    UC.event_id AS event_id,
    UC.lead_id AS CRM_lead_id,
    LD.lead_name AS lead_name,
    LD.lg_id AS lg_id,
    LD.lf_id AS lf_id,
    LD.lead_gps_lat AS lead_gps_lat,
    LD.lead_gps_long AS lead_gps_long,
    UC.lead_status AS lead_status,
    UC.meeting_type AS lead_type,
    UC.meeting_status AS meeting_status,
    UC.user_id AS user_id,
    LD1.lead_comments AS lead_comments,
    UC.address AS address,
    UC1.meeting_notes AS meeting_notes,
    LD.lead_sub_status AS lead_sub_status,
    UC.meeting_date AS meeting_date,
    UC.meeting_start_time AS meeting_schedule_time,
    UC.meeting_end_date AS meeting_end_date,
    UC.meeting_end_time AS meeting_end_time,
    UC.meeting_done_start_date AS meeting_done_start_date,
    UC.meeting_done_start_time AS meeting_done_start_time,
    UC.meeting_done_on AS meeting_done_on,
    '' AS instago_lead_id,
    UC.joint_call_along_with_l1 JointCallDoneWithL1UserId,
    UC.joint_call_along_with_l2 JointCallDoneWithL2UserId,
    UC.is_joint_call jointCallDoneFlag,
    UC.lead_contact AS lead_contact,
    LD.lead_zipcode pincode,
    LD.lead_state state,
    LD.lead_city city,
    IF(LD.lead_sub_campaign_code='' or LD.lead_sub_campaign_code is NULL, LD.campaign_code, LD.lead_sub_campaign_code) AS Campaign_Code,
    FA.s_user_row_id as user_row_id,
    UC.CRM_lead_sync_status CRM_lead_sync_status
FROM h1_user_calendar AS UC 
LEFT Join h1_lead_details AS LD ON LD.CRM_lead_id  = UC.lead_id
LEFT Join h1_user_calendar_notes as UC1 on UC1.event_id = UC.event_id
LEFT JOIN h1_fls_app_version AS FA ON UC.user_id = FA.user_id
LEFT JOIN h1_lead_details_comments LD1 on LD1.CRM_lead_id = UC.lead_id
WHERE UC.meeting_date >= date_format((current_timestamp - interval '45' day),'%Y%m%d')
       AND UC.meeting_done_on = ''
       AND UC.meeting_status = 'N'
       AND UC.meeting_type = 'Lead'
        AND UC.event_operation != ''
        AND UC.event_operation is not null
        and UC.CRM_lead_sync_status != 'Failed'
    ) AS res where lower(channel) like '%direct%' or lower(channel) like '%speciality%' or lower(channel) like '%protection%'
####################SELECT
    res.channel AS Channel,
    res.sub_channel AS Sub_Channel,
    res.CRM_lead_id AS CRMLeadID,
    res.lead_name AS Fname,
    res.user_id AS Lead_Assigned_to_Code,
    res.lead_gps_lat AS Lead_Latitude,
    res.lead_gps_long AS Lead_Longitude,
    res.at_branch AS AtBranch,
    IF(res.at_branch='False', 'NA', res.branch_name) AS BranchName,
    res.lead_status AS Lead_Status,
    CASE 
        WHEN LENGTH(res.lead_contact) >= 10 THEN 
            concat('XXXXXXXXX',SUBSTRING(res.lead_contact, 10, LENGTH(res.lead_contact))) 
    END AS Lead_Contact,
    IF(res.lg_id = res.lf_id , 'YES', 'NO') AS LeadSourceSLG,
    CASE
        WHEN res.lead_type = 'Grab' THEN
            'G'
        WHEN res.lead_type = 'Auto Allocate' THEN
            'A'
        ELSE
            'NA'
    END AS LeadType,
    TRY(date_format(date_parse(res.meeting_done_start_date||res.meeting_done_start_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Actual_Appointment_time,
    TRY(date_format(date_parse(res.meeting_end_date||res.meeting_end_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Meeting_End_Date_Time,
    TRY(date_format(date_parse(res.meeting_done_start_date||res.meeting_done_start_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Meeting_Start_Date_Time,
    TRY(ABS(date_diff('second',
        date_parse(res.meeting_done_start_date||res.meeting_done_start_time,'%Y%m%d%h:%i %p'),
        date_parse(res.meeting_end_date||res.meeting_end_time,'%Y%m%d%h:%i %p')
    )))AS TimeSpent,
    res.fls_id AS fls_id,
    res.pincode AS Pincode,
    res.city AS City,
    res.Campaign_Code AS Campaign_Code,
    res.state AS State,
    TRY(date_format(date_parse(res.meeting_date||res.meeting_schedule_time,'%Y%m%d%h:%i %p'),'%Y-%m-%d %H:%i:%S')) AS Meeting_Appointment_time,
    IF(res.meeting_status = 'Y', 'MET', 'NOT MET') AS Meeting_Status,
    res.instago_lead_id AS Geo_Lead_Id,
    res.address AS Address,
    res.lead_comments AS Lead_Comments,
    res.lead_sub_status AS Lead_Sub_Disposition_Status,
    res.meeting_notes AS Meeting_Comments,
    res.meeting_done_on AS Meeting_mode,
    CASE
        WHEN res.jointCallDoneFlag = 'True' THEN
            res.jointCallDoneFlag
        WHEN res.jointCallDoneFlag = 'False' THEN
            res.jointCallDoneFlag
        ELSE
            ''
    END AS jointMeetingDoneFlag,
    case when res.JointCallDoneWithL1UserId =  'True' then res.l1_code else '' end as JointMeetingDoneWithL1UserId,
    res.accept_reject_noti_sent_l1 As AcceptRejectNotificationSentL1,
    res.accept_reject_noti_sent_l1_dttm As AcceptRejectNotificationSentL1TimeStamp,
    res.JointCallWithL1SameLocation as JointMeetingWithL1SameLocation,
    res.JointCallL1Response as JointMeetingL1Response,
    case when res.JointCallDoneWithL2UserId =  'True' then res.l2_code else '' end as JointMeetingDoneWithL2UserId,
    res.accept_reject_noti_sent_l2 As AcceptRejectNotificationSentL2,
    res.accept_reject_noti_sent_l2_dttm As AcceptRejectNotificationSentL2TimeStamp,
    res.JointCallWithL2SameLocation as JointMeetingWithL2SameLocation,
    res.JointCallL2Response as JointMeetingL2Response
    
FROM (

SELECT
    FA.channel AS channel,
    FA.sub_channel as sub_channel,
    FA.l1_code as l1_code,
    FA.l2_code as l2_code,
    FA.fls_id as fls_id,
    UC.event_id AS event_id,
    UC.lead_id AS CRM_lead_id,
    LD.lead_name AS lead_name,
    LD.lg_id AS lg_id,
    LD.lf_id AS lf_id,
    UC.lead_gps_lat AS lead_gps_lat,
    UC.lead_gps_long AS lead_gps_long,
    UC.at_branch AS at_branch,
    UC.branch_name AS branch_name,
    UC.lead_status AS lead_status,
    UC.meeting_type AS lead_type,
    UC.meeting_status AS meeting_status,
    UC.user_id AS user_id,
    LD1.lead_comments AS lead_comments,
    UC.address AS address,
    UC.accept_reject_noti_sent_l1,
    UC.accept_reject_noti_sent_l1_dttm,
    UC.accept_reject_noti_sent_l2,
    UC.accept_reject_noti_sent_l2_dttm,
    UC1.meeting_notes AS meeting_notes,
    LD.lead_sub_status AS lead_sub_status,
    UC.meeting_date AS meeting_date,
    UC.meeting_start_time AS meeting_schedule_time,
    UC.meeting_end_date AS meeting_end_date,
    UC.meeting_end_time AS meeting_end_time,
    UC.meeting_done_start_date AS meeting_done_start_date,
    UC.meeting_done_start_time AS meeting_done_start_time,
    UC.meeting_done_on AS meeting_done_on,
    '' AS instago_lead_id,
    UC.joint_call_along_with_l1 JointCallDoneWithL1UserId,
    UC.joint_call_along_with_l2 JointCallDoneWithL2UserId,
    IF((UC.joint_call_along_with_L1_same_loc = 'True' and UC.joint_call_L1_response = 'Accept') or (UC.joint_call_along_with_L2_same_loc = 'True' and UC.joint_call_L2_response = 'Accept'),'True',IF(UC.joint_call_along_with_L1_same_loc = '' and UC.joint_call_along_with_L2_same_loc = '','','False')) as jointCallDoneFlag,
    UC.joint_call_along_with_L1_same_loc As JointCallWithL1SameLocation,
    UC.joint_call_along_with_L2_same_loc As JointCallWithL2SameLocation,
    UC.joint_call_L1_response As JointCallL1Response,
    UC.joint_call_L2_response As JointCallL2Response,
    UC.lead_contact AS lead_contact,
    LD.lead_zipcode pincode,
    LD.lead_state state,
    LD.lead_city city,
    IF(LD.lead_sub_campaign_code='' or LD.lead_sub_campaign_code is NULL, LD.campaign_code, LD.lead_sub_campaign_code) AS Campaign_Code,
    FA.s_user_row_id as user_row_id,
    UC.CRM_lead_sync_status CRM_lead_sync_status
FROM h1_user_calendar AS UC 
LEFT Join h1_lead_details AS LD ON LD.CRM_lead_id  = UC.lead_id
LEFT Join h1_user_calendar_notes as UC1 on UC1.event_id = UC.event_id
LEFT JOIN h1_fls_app_version AS FA ON UC.user_id = FA.user_id
LEFT JOIN h1_lead_details_comments AS LD1 on LD1.CRM_lead_id = UC.lead_id
WHERE UC.meeting_date >= date_format((current_timestamp - interval '45' day),'%Y%m%d')
       AND UC.meeting_done_on = 'In-Person'
       OR UC.event_operation = 'Start Meeting'
       AND UC.meeting_type = 'Lead'
        AND UC.event_operation != ''
        AND UC.event_operation is not null
        and UC.CRM_lead_sync_status != 'Failed'
    ) AS res where lower(channel) like '%direct%' or lower(channel) like '%speciality%' or lower(channel) like '%protection%'
####################
SELECT 
s.user_id as "Employee Id",
f.user_name as "Employee Name",
f.l1_name as "Reviewer 1 Name",
f.l2_name as "Reviewer 2 Name",
TRY(date_format(date_parse(s."record_last_updated",'%Y-%m-%dT%H:%i:%s.%fZ'),'%d-%m-%Y %H:%i')) as "Employee Comment Date",
s.user_commitment as "Employee Commitment",
c."leadsection.l1.commentmessage" as "Reviewer 1 comment(LEADS)",
c."leadsection.l2.commentmessage" as "Reviewer 2 comment(LEADS)",
c."campaignsection.l1.commentmessage" as "Reviewer 1 comment(CAMPAIGN)",
c."campaignsection.l2.commentmessage" as "Reviewer 2 comment(CAMPAIGN)",
c."iearnsection.l1.commentmessage" as "Reviewer 1 comment(IEARN)",
c."iearnsection.l2.commentmessage" as "Reviewer 2 comment(IEARN)",
IF(
LEAST(
IF(c."campaignsection.l1.updatedtimestamp"='' or c."campaignsection.l1.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."campaignsection.l1.updatedtimestamp"),
IF(c."leadsection.l1.updatedtimestamp"='' or c."leadsection.l1.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."leadsection.l1.updatedtimestamp"),
IF(c."iearnsection.l1.updatedtimestamp"='' or c."iearnsection.l1.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."iearnsection.l1.updatedtimestamp")
) = '3000-07-05 15:18:06.585170',NULL,
date_format(date_parse(LEAST(
IF(c."campaignsection.l1.updatedtimestamp"='' or c."campaignsection.l1.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."campaignsection.l1.updatedtimestamp"),
IF(c."leadsection.l1.updatedtimestamp"='' or c."leadsection.l1.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."leadsection.l1.updatedtimestamp"),
IF(c."iearnsection.l1.updatedtimestamp"='' or c."iearnsection.l1.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."iearnsection.l1.updatedtimestamp")
),'%Y-%m-%d %H:%i:%s.%f'),'%d-%m-%Y %H:%i')     
)  as "Reviewer 1 comment date",
IF( 
LEAST(
IF(c."campaignsection.l2.updatedtimestamp"='' or c."campaignsection.l2.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."campaignsection.l2.updatedtimestamp"),
IF(c."leadsection.l2.updatedtimestamp"='' or c."leadsection.l2.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."leadsection.l2.updatedtimestamp"),
IF(c."iearnsection.l2.updatedtimestamp"='' or c."iearnsection.l2.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."iearnsection.l2.updatedtimestamp")
) = '3000-07-05 15:18:06.585170',NULL,
date_format(date_parse(LEAST(
IF(c."campaignsection.l2.updatedtimestamp"='' or c."campaignsection.l2.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."campaignsection.l2.updatedtimestamp"),
IF(c."leadsection.l2.updatedtimestamp"='' or c."leadsection.l2.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."leadsection.l2.updatedtimestamp"),
IF(c."iearnsection.l2.updatedtimestamp"='' or c."iearnsection.l2.updatedtimestamp" is NULL,'3000-07-05 15:18:06.585170',c."iearnsection.l2.updatedtimestamp")
)  ,'%Y-%m-%d %H:%i:%s.%f'),'%d-%m-%Y %H:%i') 
) as "Reviewer 2 comment date"

FROM
"instago_mis"."instago_prod_h1_save_user_committment_partitioned" as s,
"instago_mis"."instago_prod_h1_user_manager_chat_partitioned" as c,
"instago_mis"."instago_prod_h1_fls_app_version_data" as f
WHERE
s.user_commitment !='' 
and s.record_last_updated !=''
and c.date_range >= date_format((current_timestamp - interval '30' day),'%Y-%m-%d')
and (s.user_id = c.user_id and s.user_id = f.user_id) and s.week_range = c.source_key
####################select wd.unique_lecture_code AS "Unique code",
wd.user_id AS "FLS code",
wd.fls_name AS "FLS Name",
 TRY(date_format(date_parse(wd.tagged_date,'%Y-%m-%d %H:%i:%s'),'%d-%m-%Y')) as "tagged date",
 TRY(date_format(date_parse(wd.tagged_date,'%Y-%m-%d %H:%i:%s'),'%H:%m:%s')) as "tagged time",
wd.location AS "Location",
wd.no_of_lecture_attendees AS "No of attendees",
wd.worksite_type AS "Worksite Type",
wd.unit_name AS "Unit Name",
wd.access_type AS "Access type",
wd.influencer_name AS "Influencer Name",
wd.influencer_type AS "Influencer Type",
wd.influence_contact_no AS "Influencer Mobile"
from "h1_worksite_code" AS wd
####################SELECT
UC.lead_id As "Lead id",
UC.name AS "Lead name",
UC.lead_worksite_code As "Unique code",
UC.lead_contact As "Mobile",
TRY(date_format(date_parse(UC.meeting_date,'%Y%m%d'),'%d-%m-%Y')) as "Date of creation", 
WC.worksite_type As "Worksite Type",
WC.location As "Location", 
WC.No_Of_Lecture_Attendees As "No of attendees", UC.lead_status As "Status",
WC.user_id As "FLS Code",
WC.fls_name As "FLS Name",
TRY(date_format(date_parse(UC.meeting_date,'%Y%m%d'),'%d-%m-%Y')) as "Conversion date"
FROM h1_user_calendar AS UC
INNER JOIN h1_worksite_code AS WC ON UC.lead_worksite_code = WC.unique_lecture_code
WHERE UC.meeting_type = 'Lead' and UC."lead_worksite_code" != '' and UC.meeting_date >= date_format((current_timestamp - interval '45' day),'%Y%m%d')
####################select TRY(date_format(date_parse(wd.worksite_date,'%m/%d/%Y %H:%i:%s'),'%d-%m-%Y')) as "Worksite date",
TRY(date_format(date_parse(wd.worksite_date,'%m/%d/%Y %H:%i:%s'),'%H:%m:%s')) as "Worksite time",
wd.worksite_type AS "Worksite Type",
wd.location AS "Location",
wd.no_of_lecture_attendees AS "No of attendees",
wd.unique_lecture_code AS "Unique code",
wd.user_id AS "FLS code",
wd.fls_name AS "FLS Name",
TRY(date_format(date_parse(wd.worksite_date,'%m/%d/%Y %H:%i:%s'),'%d-%m-%Y')) as "Worksite entry date",
TRY(date_format(date_parse(wd.worksite_date,'%m/%d/%Y %H:%i:%s'),'%H:%m:%s')) as "Worksite entry time"
from "h1_worksite_code" AS wd
####################SELECT
UC.lead_id As "Lead id",
UC.name AS "Lead name",
UC.lead_worksite_code As "Unique code",
UC.lead_contact As "Mobile",
TRY(date_format(date_parse(UC.meeting_date,'%Y%m%d'),'%d-%m-%Y')) as "Date of creation", 
WC.worksite_type As "Worksite Type",
WC.location As "Location", 
WC.No_Of_Lecture_Attendees As "No of attendees", UC.lead_status As "Status",
WC.user_id As "FLS Code",
WC.fls_name As "FLS Name",
TRY(date_format(date_parse(UC.meeting_date,'%Y%m%d'),'%d-%m-%Y')) as "Conversion date"
FROM h1_user_calendar AS UC
INNER JOIN h1_worksite_code AS WC ON UC.lead_worksite_code = WC.unique_lecture_code
WHERE UC.lead_worksite_code != ''
####################SELECT
UC.lead_id As "Lead id",
UC.name AS "Lead name",
UC.lead_worksite_code As "Unique code",
UC.lead_contact As "Mobile",
TRY(date_format(date_parse(UC.meeting_date,'%Y%m%d'),'%d-%m-%Y')) as "Date of creation", 
WC.worksite_type As "Worksite Type",
WC.location As "Location", 
WC.No_Of_Lecture_Attendees As "No of attendees", UC.lead_status As "Status",
WC.user_id As "FLS Code",
WC.fls_name As "FLS Name",
TRY(date_format(date_parse(UC.meeting_date,'%Y%m%d'),'%d-%m-%Y')) as "Conversion date"
FROM h1_user_calendar AS UC
INNER JOIN h1_worksite_code AS WC ON UC.lead_worksite_code = WC.unique_lecture_code
####################Select
UC.lead_id As "Lead id", UC.name AS "Lead name", UC.lead_worksite_code As "Unique code", UC.lead_contact As "Mobile", 
UC.meeting_date As "Date of creation", WC.worksite_type As "Worksite Type", WC.location As "Location", 
WC.No_Of_Lecture_Attendees As "No of attendees", UC.lead_status As "Status", WC.fls_name As "FLS Name", 
UC.meeting_date As "Conversion date" FROM "instago_mis"."h1_user_calendar" AS UC 
INNER JOIN "instago_mis"."h1_worksite_code" AS WC ON UC.lead_worksite_code = WC.unique_lecture_code 
WHERE (TRY(date_trunc('month',date_parse(UC.meeting_date,'%Y%m%d'))) =TRY(date_trunc('month',current_date - interval '1' day)) and
TRY(date_trunc('year',date_parse(UC.meeting_date,'%Y%m%d'))) = date_trunc('year',current_date - interval '1' day))
####################lead_login_logs,lead_tracking_successful_unmasked_custom,lead_tracking_Unsuccessful_meeting,lead_tracking_successfull_meeting,MIS_WAR,MIS_Shaurya_Worksite,MIS_Shaurya_Leads,MIS_worksite_data_complete,Shaurya_Leads_2_,Shaurya_Leads_Prod_query,Shaurya_Monthly,
####################temp_lambda,temp_lambda,temp_lambda,temp_lambda,temp_lambda,temp_lambda,temp_lambda,temp_lambda,temp_lambda,temp_lambda,temp_lambda,
"""

def lambda_handler(event, context):
    query_list = queries.split('####################')

    print("QUERY LIST ",query_list)

    names = query_list[-2].split(',')
    names = names[:-1]
    output_folder = query_list[-1].split(',')
    output_folder = output_folder[:-1]
    print("output_folder", output_folder)
    for ind, query in enumerate(query_list[:-2]):
        print("QUERY ",query)
        RESULT_FOLDER = "query-data-result/"+output_folder[ind]
        Name = names[ind]
        dest_file_name = f"{RESULT_FOLDER}/{Name}{DAY}{MONTH}{YEAR}.csv"

        response = client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={'Database': ATHENA_DB},
            ResultConfiguration={
                'OutputLocation': f"s3://{S3_BUCKET}/{RESULT_FOLDER}"}
        )
        print("resp: ", response)
        temp_file_name = Name+DAY+MONTH+YEAR
        print("temp_file_name:", temp_file_name)
        query_execution_id = response['QueryExecutionId']
        source_file_name = f"{S3_BUCKET}/{RESULT_FOLDER}/{query_execution_id}.csv"
        dest_file_name = f"{RESULT_FOLDER}/"+temp_file_name+".csv"
        print("dest_file_name:", dest_file_name)

        for i in range(1, 1 + RETRY_COUNT):
            query_status = client.get_query_execution(
                QueryExecutionId=query_execution_id)

            query_execution_status = query_status['QueryExecution']['Status']['State']

            print("exec status: ", query_status['QueryExecution']['Status'])

            if query_execution_status == 'SUCCEEDED':
                print("STATUS:" + query_execution_status)

                # Rename the file
                # s3.Object(S3_BUCKET, dest_file_name).copy_from(
                    # CopySource=source_file_name)
                
                #USE MULTIPART THREADING COPY INSTEAD OF COPY_FROM
                copy_source = {
                            'Bucket': f"{S3_BUCKET}",
                            'Key': f"{RESULT_FOLDER}/{query_execution_id}.csv"
                            }
                s3.meta.client.copy(copy_source, S3_BUCKET, dest_file_name)
                #END OF MULTIPART COPY

                s3.Object(
                    S3_BUCKET, f"{RESULT_FOLDER}/{query_execution_id}.csv").delete()
                s3.Object(
                    S3_BUCKET, f"{RESULT_FOLDER}/{query_execution_id}.csv.metadata").delete()
                break

            if query_execution_status == 'FAILED':
                print("STATUS:" + query_execution_status)
            else:
                print("STATUS:" + query_execution_status)
                time.sleep(i)
        else:
            client.stop_query_execution(QueryExecutionId=query_execution_id)
            print('TIME OUT')
